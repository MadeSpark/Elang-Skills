---
name: elang-build
description: 把易语言（.e / .ec）编译成原生 exe/dll 或验证其能否编译时使用——无需打开 IDE。包含两条无头编译通道的选择与完整命令行：e-packager semantic 语义编译（本套装实测可用的主通道，含 lib 相邻布局、--e-dir、--x86-decoder、VC6 链接库等全部环境配方，封装成 ecompile.py 一条命令）与 AutoLinker 无头编译（含 compile_with_output_path、项目级按配置编译、MCP 边界，以及**旧版 IDE 三道版本闸门会拒载 AutoLinker 的实测结论与判定步骤**）。另含程序入口优先级（_启动窗口 会无视 _启动子程序）、控制台 EXE 验证模式与易模块自测、编译目标速查、成功判据（artifact_verified，别信旧产物）与排错表。触发词：编译、编译exe、出exe、静态编译、无头编译、命令行编译、发布、构建、AutoLinker、黑月编译、ecompile、编译失败、不能载入支持库、链接错误、LNK、控制台验证、标准输出、_启动子程序、_启动窗口、程序入口。
---

# 易语言无头编译与构建验证

> 三技能分工：`elang-ai-coding` 管「写对代码」，`e2txt-cli` 管「.e ⇄ 文本」，**本技能管「编译成产物 + 编译期验证」**。

本文路径占位符：`<SCRIPTS>` = 本技能目录下 `scripts`（内含 `ecompile.py`）；`<ASSETS>` = 技能目录下 `assets`；`<PY>` = `python`（3.9+，脚本零第三方依赖）。技能是自包含的，装到任何 AI 工具目录都跟着走；`e-packager.exe` 在**套装**的 `e2txt-cli` 技能 `assets/` 里（`ecompile.py` 会自动跨技能定位）。

> 配套必读（都在本技能 `references/` 或相关技能里，按需加载）：
> - `references/AutoLinker与无头编译.md`：AutoLinker 三通道 + **装之前必看的版本闸门**
> - 《程序入口与编译验证》（在 `elang-ai-coding` 技能）：入口优先级、控制台验证、易模块自测
> - 《e-packager》（在 `e2txt-cli` 技能）：semantic 编译的完整实测记录

## 0. 先选通道

| 场景 | 走哪条 |
|---|---|
| **默认**：无 IDE、无第三方依赖，直接出原生 exe/dll | **通道 A：e-packager semantic**（`ecompile.py` 一条命令） |
| 已装新版易语言 + AutoLinker.fne 且能正常加载（`ecompile.py --doctor` 与 §AutoLinker 参考 §1 判定） | 通道 B：AutoLinker 无头编译（支持静态编译、目标更全） |
| 只要检查语法/类型，不出产物 | `e-packager validate <文本目录>`（见 e2txt-cli 技能） |

**两条通道编译出的都是原生 x86 产物**；`置入代码` 的机器码字节在通道 A 实测真实执行（NOP/INT3 双向验证），换任何后端都按《置入代码与机器码》§5 重验。

## 1. 通道 A：`ecompile.py`（推荐，开箱即用）

e-packager（内置在 `e2txt-cli` 技能 `assets/e-packager.exe`，MIT）自带语义编译后端：易语言源码 → 生成 C++ → MSVC 编译 → 链接易语言静态库。脚本封装了四个缺一即败的环境配方（lib 相邻布局、`--e-dir`、`--x86-decoder`、`LIB=VC6 链接库`）：

```bash
python "<SCRIPTS>/ecompile.py" 输入.e 输出.exe                 # auto 子系统
python "<SCRIPTS>/ecompile.py" 输入.e 输出.exe --subsystem console
python "<SCRIPTS>/ecompile.py" --doctor [--json]               # 环境自检
python "<SCRIPTS>/ecompile.py" 输入.e 输出.exe --json --keep   # JSON 结果 + 保留中间产物(.generated.cpp/.obj)
```

- `--json` 契约：`{"ok":true,"output":"…","outputSize":N,"compile_mode":"semantic","generatedCpp":"…"}`；失败时 `error` + `diagnostics`（原始编译输出尾部 4000 字符）+ `exitCode`。退出码：0 成功 / 2 环境错误 / 3 编译失败 / 4 自检未通过。
- 定位顺序（都可被参数或环境变量覆盖）：e-packager ← `--packager` / `E_PACKAGER` / `e2txt-cli` 技能 assets / `PATH`；易语言目录 ← `--e-dir` / `ELANG_DIR` / 注册表 Install\Path / 常见路径。
- **成功判据**：脚本已内置「产物存在且非空 + compile 行解析」；**绝不以旧产物存在判成功**（脚本每次先删旧产物）。
- 编译失败最常见原因（全部实测过）：诊断里 `unknown_call:_Lib0CmdXXX` = 支持库没解析到（脚本已自动建 lib 联接，若仍出现说明工程用了 lib 里没有的库）；`mfc_runtime_file_not_found` / `LNK1104 libcimt` = VC6 链接库路径没配好（脚本已设 `LIB`，手工跑命令行时容易漏）；`expression_parse_failed` = 源码文本本身有解析不了的字符（比 e2txt 严格，控制字节/非法字面量都会拒）。
- **实测缺陷**：`标准输出` 的产物运行会崩溃；控制台验证改用「写结果文件 → 读回」，见《程序入口与编译验证》§2。
- MSVC 要求：机器上有 VS（含 C++ 生成工具）即可；产物含 `.pdb`，中间 `.cpp/.obj` 用 `--keep` 留着排错。

## 2. 通道 B：AutoLinker 无头编译

命令行、成功判据、退出码、项目级配置编译、MCP 边界 → **`references/AutoLinker与无头编译.md`**（改编自上游技能并含实测修订）。

⚠️ **装 AutoLinker 之前先做 §1 闸门判定**：旧版 IDE 构建会以「不能载入支持库 AutoLinker 1.0版」拒绝加载（三道闸：要求的系统版本 / 要求的核心库版本 / `LBS_LIB_INFO2` 标志，与授权字段内容无关，30 个历史版本全系命中）。判定步骤与解锁条件（升级 IDE）见该参考 §1。

## 3. 编译期验证工作流（AI 排错闭环）

```
1. 写/改代码（elang-ai-coding 的格式铁律 + echeck/rtcheck）
2. t2e 出 .e（e2txt-cli；绝不覆盖原件）
3. ecompile.py 出产物（通道 A）或 AutoLinker 无头编译（通道 B）
4. 失败 → 读 diagnostics 第一组根因 → 修 → 重跑（别叠补丁）
5. 成功 → 运行产物做行为验证：
     控制台验证（写文件读回，见《程序入口与编译验证》§2）
     调试输出验证（elang-debug 技能：加壳 → 调试运行 → 实时抓 输出调试文本）
6. 涉及 UI/线程/网络/DLL 的改动：编译通过 ≠ 行为正确，补真实场景测试
```

## 4. 红线（与全套装一致）

1. 绝不覆盖、不「修补」用户的原 `.e`；产物与中间文件都放你自己的目录。
2. 绝不 `taskkill /F /IM e.exe`——AutoLinker 无头实例只按自己启动的 PID 精确清理。
3. 技能/脚本不写任何本机绝对路径；外部依赖一律「怎么找」。
4. 机器码相关改动按《置入代码与机器码》核对，INT3 等调试字节不进交付物。

## 5. 文件地图

| 文件 | 作用 |
|---|---|
| `<SCRIPTS>/ecompile.py` | 无头编译封装 + `--doctor` 自检（零第三方依赖，Python 3.9+） |
| `references/AutoLinker与无头编译.md` | 通道 B 全量知识 + 版本闸门实测 |
| `e2txt-cli` 技能 `assets/e-packager.exe` | 语义编译器本体（通道 A 调它） |
| `e2txt-cli` 技能 `references/e-packager.md` | 通道 A 的实测细节与缺陷表 |
